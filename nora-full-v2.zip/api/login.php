<?php
require_once __DIR__ . '/../db.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['status' => 'error', 'message' => 'POST required']);
}

$db = getDB();

// Check maintenance mode
$cfg = $db->query("SELECT cfg_value FROM app_config WHERE cfg_key='maintenance_mode'")->fetch();
if ($cfg && $cfg['cfg_value'] === '1') {
    json_out(['status' => 'error', 'message' => 'maintenance', 'code' => 503]);
}

$username  = post('username');
$password  = post('password');
$device_id = post('device_id');
$timestamp = post('timestamp');

if (!$username || !$password) {
    json_out(['status' => 'error', 'message' => 'Missing credentials']);
}

$stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND status != 'expired' LIMIT 1");
$stmt->execute([$username]);
$user = $stmt->fetch();

if (!$user) {
    json_out(['status' => 'error', 'message' => 'User not found']);
}

if (!password_verify($password, $user['password'])) {
    json_out(['status' => 'error', 'message' => 'Invalid password']);
}

if ($user['status'] === 'blocked') {
    json_out(['status' => 'blocked', 'message' => 'Account blocked. Contact @noraphillip on Telegram.', 'limit' => 0]);
}

if ($user['signal_limit'] <= 0) {
    json_out(['status' => 'blocked', 'message' => 'Signal limit reached. Contact @noraphillip to renew.', 'limit' => 0]);
}

// Generate token and update device
$token = bin2hex(random_bytes(20));
$stmt = $db->prepare("UPDATE users SET token=?, device_id=?, updated_at=NOW() WHERE id=?");
$stmt->execute([$token, $device_id ?: $user['device_id'], $user['id']]);

log_activity($db, 'login', "User {$user['username']} logged in from device {$device_id}", $user['id']);

json_out([
    'status'  => 'success',
    'token'   => $token,
    'user_id' => $user['id'],
    'username'=> $user['username'],
    'plan'    => $user['plan'],
    'limit'   => (int)$user['signal_limit'],
    'balance' => (float)$user['balance'],
]);
