<?php
require_once __DIR__ . '/../db.php';
cors();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(['status' => 'error', 'message' => 'POST required']);
}

$db = getDB();

// Check if registration is open
$cfg = $db->query("SELECT cfg_value FROM app_config WHERE cfg_key='registration_open'")->fetch();
if ($cfg && $cfg['cfg_value'] === '0') {
    json_out(['status' => 'error', 'message' => 'Registration is currently closed.']);
}

$username  = post('username');
$password  = post('password');
$device_id = post('device_id');

if (!$username || !$password || !$device_id) {
    json_out(['status' => 'error', 'message' => 'Missing required fields']);
}

if (strlen($username) < 3 || strlen($username) > 50) {
    json_out(['status' => 'error', 'message' => 'Username must be 3-50 characters']);
}

$exists = $db->prepare("SELECT id FROM users WHERE username=? LIMIT 1");
$exists->execute([$username]);
if ($exists->fetch()) {
    json_out(['status' => 'error', 'message' => 'Username already taken']);
}

$hash  = password_hash($password, PASSWORD_DEFAULT);
$token = bin2hex(random_bytes(20));

// New users get the Starter plan by default
$stmt = $db->prepare(
    "INSERT INTO users (username, password, device_id, token, plan, signal_limit, balance, status) VALUES (?,?,?,?,?,?,?,?)"
);
$stmt->execute([$username, $hash, $device_id, $token, 'Starter', 50, 0, 'active']);
$userId = $db->lastInsertId();

log_activity($db, 'register', "New device registered: {$username} ({$device_id})", $userId);

json_out([
    'status'  => 'success',
    'token'   => $token,
    'user_id' => $userId,
    'username'=> $username,
    'plan'    => 'Starter',
    'limit'   => 50,
    'balance' => 0,
]);
