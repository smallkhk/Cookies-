<?php
// ── DATABASE ──────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_NAME', 'nora_db');       // Change to your cPanel DB name
define('DB_USER', 'nora_user');     // Change to your cPanel DB user
define('DB_PASS', 'your_db_pass'); // Change to your DB password

// ── ADMIN PANEL ───────────────────────────────────────
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'nora2026');  // Change this!

// ── APP ───────────────────────────────────────────────
define('API_SECRET', 'nora_secret_2026');  // Used in signing

// CORS — set to your app domain or * for open
define('CORS_ORIGIN', '*');
